#define STEP 3
#include "dynarec_arm64_emit_tests.c"
